package cs.school.noza;

import android.app.Activity;
import android.os.Bundle;

public class page7 extends Activity{
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.page7);
		
	}
}