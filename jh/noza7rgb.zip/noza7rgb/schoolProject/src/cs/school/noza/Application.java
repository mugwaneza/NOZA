package cs.school.noza;

public class Application {    private String id;
private String head ;
private String who;
private String message;


public String getId() {
    return id;
}
public void setId(String ahantu) {
    this.id = ahantu;
}
public String getHead() {
    return head;
}
public void setHead(String itariki) {
    this.head = itariki;
}
public String getWho() {
    return who;
}
public void setWho(String igihe) {
    this.who = igihe;
}
public String getMessage() {
    return message;
}
public void setMessage(String kubera) {
    this.message= kubera;
}
public String getWhere() {
    return message;
}
  
}
