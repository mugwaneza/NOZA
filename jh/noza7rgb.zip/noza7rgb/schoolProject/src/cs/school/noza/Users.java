package cs.school.noza;

public class Users {

	int id;
    String identity;
    String location;
    String date;
    String time;
    String why;
    String RGBinstitution;
    String text;
    
     
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    
    public String getidentity() {
        return identity;
    }
    public void setidentity(String identity) {
        this.identity = identity;
    }
    
    public String getlocation() {
        return location;
    }
    public void setlocation(String location) {
        this.location = location;
    }
    public String getdate() {
        return date;
    }
    public void setdate(String date) {
        this.date = date;
    }
     
    public String gettime() {
        return time;
    }
    public void settime(String time) {
        this.time = time;
    }
    
    public String getwhy() {
        return why;
    }
    public void setwhy(String why) {
        this.why = why;
    }
    
    public String getRGBinstitution() {
        return RGBinstitution;
    }
    public void setRGBinstitution(String RGBinstitution) {
        this.RGBinstitution = RGBinstitution;
    }
    
    public String gettext() {
        return text;
    }
    public void settext(String text) {
        this.text = text;
    }
}