package com.rgb2.noza;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import cs.school.noza.R;
import cs.school.noza.citizenauthentication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class registerpage extends Activity {
	
	String[] districts = {
			"Bugesera Eastern Province",
			"Gatsibo Eastern Province",
			"Kayonza Eastern Province",
			"Kirehe Eastern Province",
			"Ngoma  Eastern Province",
			"Nyagatare Eastern Province",
			"Rwamagana Eastern Province	",
			"Gasabo Kigali, City",
			"Kicukiro Kigali, City",
			"Nyarugenge Kigali, City",
			"Burera Northern Province",
			"Gakenke Northern Province",
			"Gicumbi Northern Province",
			"Musanze Northern Province",
			"Rulindo Northern Province",
			"Gisagara Southern Province",
			"Huye Southern Province",
			"Kamonyi Southern Province",
			"Muhanga Southern Province",
			"Nyamagabe Southern Province",
			"Nyanza Southern Province",
			"Nyaruguru Southern Province",
			"Ruhango Southern Province",
			"Karongi Western Province",
			"Ngororero Western Province",
			"Nyabihu Western Province",
			"Nyamasheke Western Province",
			"Rubavu Western Province",
			"Rusizi Western Province",
			"Rutsiro Western Province",
			"Mukamira Western Province",
			
	};

	
	

	private String names;
	private String  tel;
	private String age;
	private String gender;
	private String  email;
	private String password; 
	private String district; 
	
	
	
	InputStream is=null;
	String result=null;
	String line=null;
	int code;
	Button send ;
	
	private	EditText a ;
	private	EditText b;
	private	EditText c;
	private	AutoCompleteTextView d;

	private	EditText e;
	private	EditText f;
	private	EditText g;
	
	
	private RadioGroup sexes;
    private RadioButton h;
    private RadioButton j;


	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.registerpage);
		
		if (android.os.Build.VERSION.SDK_INT > 9) {
		    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		    StrictMode.setThreadPolicy(policy);
		}
		
		
	// Edit Text
	  a = (EditText) findViewById(R.id.firstname);
	  b = (EditText) findViewById(R.id.tel);
	  c = (EditText) findViewById(R.id.age);
	  d = (AutoCompleteTextView) findViewById(R.id.district); 
	  e= (EditText) findViewById(R.id.password);
	 f= (EditText) findViewById(R.id.comfirmpass);
	 g= (EditText) findViewById(R.id.email1);
	 // find the radiobutton by returned id
	 h = (RadioButton) findViewById(R.id.radio_male);
	j = (RadioButton) findViewById(R.id.radio_female);
	  
  
	  sexes = (RadioGroup)findViewById(R.id.radioGroup1);
	  
	// enable autocompletion
	  
	  ArrayAdapter<String> adapter= new ArrayAdapter<String>(this, 
      		android.R.layout.simple_dropdown_item_1line,districts);
	  
	  d.setThreshold(2);
      d.setAdapter(adapter);
	  
	  // radio button
	  
      
      
      
      
      
      sexes.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

          @Override
          public void onCheckedChanged(RadioGroup group, int checkedId) 
          {
              RadioButton checkedRadioButton = (RadioButton) findViewById(checkedId);
              String text = checkedRadioButton.getText().toString();
              Toast.makeText(getApplicationContext(), text, Toast.LENGTH_SHORT).show();
          }
      });
      
      
      	
	// Create button
			Button send = (Button)findViewById(R.id.register);
			 send.setOnClickListener(new View.OnClickListener() {
				
			@Override
			public void onClick(View v) {
				
				
				 String naming =a.getText().toString();
                 String calling =b.getText().toString();
                 String ages= c.getText().toString();
                 String region= d.getText().toString();
                   String passwording=e.getText().toString();
                    String comfirmingpassword=f.getText().toString();
                    
                
                 // check if any of the fields are vaccant
                 if(naming.equals("")||calling.equals("")||ages.equals("")||region.equals("")||passwording.equals("")
                		 ||comfirmingpassword.equals(""))
                 {
                         Toast.makeText(getApplicationContext(), "field can not be empty", Toast.LENGTH_LONG).show();
                         return;
                 }
                 
                 //validate checkbox
                 
                
                 if(sexes.getCheckedRadioButtonId()==-1) {    
         			 Toast.makeText(getApplicationContext(), "select yr gender", Toast.LENGTH_LONG).show();
                    
         		}
                   
                 // check if both password matches
                 if(!passwording.equals(comfirmingpassword))
                 {
                     Toast.makeText(getApplicationContext(), "Password Does Not Matches", Toast.LENGTH_LONG).show();
                     return;
                 }
                 email =g.getText().toString();
					if (!isValidEmail(email)) {
						g.setError("Invalid Email");
					}
					
					
					else{
			  
							    	 insert();					      
							  			
					}	   	       
			}

		
		});
         
	}
	

 void insert()
{ 
	
	   names =a.getText().toString();	
		
		
		tel = b.getText().toString();
		email= g.getText().toString();
		age= c.getText().toString();
		
		int selectedId = sexes.getCheckedRadioButtonId();
		if(selectedId != -1) {    
		  
		   // do what you 
		gender= h.getText().toString();
		gender= j.getText().toString();
		}
			
		 district= d.getText().toString();
		 password= e.getText().toString();
		

	ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
	
	nameValuePairs.add(new BasicNameValuePair("names",names));
	nameValuePairs.add(new BasicNameValuePair("tel",tel));
	nameValuePairs.add(new BasicNameValuePair("email",email));
	nameValuePairs.add(new BasicNameValuePair("age",age));
	
	nameValuePairs.add(new BasicNameValuePair("gender",gender));
	nameValuePairs.add(new BasicNameValuePair("district",district));
	nameValuePairs.add(new BasicNameValuePair("password",password));
	nameValuePairs.add(new BasicNameValuePair("password",password));
	
	
	try
	{
	HttpClient httpclient = new DefaultHttpClient();
        HttpPost httppost = new HttpPost("http://10.0.2.2/noza/registerme.php");
        httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
        HttpResponse response = httpclient.execute(httppost); 
        HttpEntity entity = response.getEntity();
        is = entity.getContent();
        Log.e("pass 1", "connection success ");
        
      
}
    catch(Exception e)
{

    	Log.e("Pass 1", e.toString());
    	Toast.makeText(getApplicationContext(), " account successfully created !",
		Toast.LENGTH_LONG).show();
    	Intent i =new Intent(getApplication(),citizenauthentication.class);
    	startActivity (i);
    	
    	
}     
	

try
{
    BufferedReader reader = new BufferedReader
	(new InputStreamReader(is,"iso-8859-1"),8);
    StringBuilder sb = new StringBuilder();
    while ((line = reader.readLine()) != null)
{
        sb.append(line + "\n");
    }
    is.close();
    result = sb.toString();
Log.e("pass 2", "connection success ");



}
catch(Exception e)
{
	
    Log.e("Fail 2", e.toString());
}     

}

 
//validating email id
		private boolean isValidEmail(String email) {
			String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
					+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

			Pattern pattern = Pattern.compile(EMAIL_PATTERN);
			Matcher matcher = pattern.matcher(email);
			return matcher.matches();
		}
		
		
		
		
		
		
 

}

