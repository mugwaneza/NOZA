package cs.school.noza;

import cs.school.noza.R;
import android.app.Activity;
import android.os.Bundle;

public class page17 extends Activity{
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.page17);
		
	}
}